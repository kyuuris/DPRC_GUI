import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import time
import webbrowser
import win32com.client
import win32com.client
import calendar

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from datetime import datetime, timedelta, date
from outreach_functions import run_initial_outreach, run_second_outreach, run_missed_appointment
from calendar_functions import get_availability_text
from browser_setup import launch_chrome
from scheduler_window import open_scheduler_window

#pip install selenium webdriver-manager pywin32

driver = None  # Will be set after launching Chrome

def set_driver(d):
    global driver
    driver = d

def run_script(script_path, success_msg="✅ Script ran", fail_msg="❌ Failed"):
    try:
        subprocess.Popen(["python", script_path], shell=True)
    except Exception as e:
        messagebox.showerror("Error", f"Script failed: {e}")

# GUI Setup
root = tk.Tk()
root.title("Kenneth's DPRC Automation")
root.geometry("300x400")

status_label = tk.Label(root, text="🟡 Chrome not running", fg="orange")
status_label.pack(pady=10)

# Stay on Top Toggle
stay_on_top_var = tk.BooleanVar(value=True)
def toggle_stay_on_top():
    root.attributes("-topmost", stay_on_top_var.get())

stay_on_top_check = tk.Checkbutton(root, text="Stay on Top", variable=stay_on_top_var, command=toggle_stay_on_top)
stay_on_top_check.pack(pady=2)
root.attributes("-topmost", True)

# Buttons
tk.Button(root, text="Open Chrome", command=lambda: set_driver(launch_chrome(status_label, root))).pack(pady=2)

initial_frame = tk.Frame(root)
initial_frame.pack(pady=2)
initial_loops_var = tk.IntVar(value=1)
tk.Entry(initial_frame, textvariable=initial_loops_var, width=5).pack(side="right", padx=5)
tk.Button(initial_frame, text="Initial Outreach", command=lambda: run_initial_outreach(driver, initial_loops_var.get())).pack(side="right")

second_frame = tk.Frame(root)
second_frame.pack(pady=2)
second_loops_var = tk.IntVar(value=1)
tk.Entry(second_frame, textvariable=second_loops_var, width=5).pack(side="right", padx=5)
tk.Button(second_frame, text="Second Outreach", command=lambda: run_second_outreach(driver, second_loops_var.get())).pack(side="right")

missed_frame = tk.Frame(root)
missed_frame.pack(pady=2)
missed_loops_var = tk.IntVar(value=1)
tk.Entry(missed_frame, textvariable=missed_loops_var, width=5).pack(side="right", padx=5)
tk.Button(missed_frame, text="Missed Appointment", command=lambda: run_missed_appointment(driver, missed_loops_var.get())).pack(side="right")

tk.Button(root, text="Open Scheduler", command=lambda: open_scheduler_window(root, driver)).pack(pady=10)
tk.Button(root, text="Get Calendar Openings", command=lambda: run_script("automation.py")).pack(pady=2)

root.after(500, lambda: set_driver(launch_chrome(status_label, root)))

root.mainloop()