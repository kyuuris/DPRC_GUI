import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import time
import webbrowser
import win32com.client
import win32com.client
import calendar

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from datetime import datetime, timedelta, date

driver = None
password = "Asiandude@4480"  # Set your password here

def launch_chrome(status_label, root):
    global driver
    try:
        options = Options()
        options.add_argument(r"--user-data-dir=C:/Users/924199104/AppData/Local/Google/Chrome/User Data")
        options.add_argument(r"--profile-directory=Profile 2")
        options.add_argument("--disable-extensions")
        options.add_argument("--disable-sync")
        options.add_argument("--start-maximized")
        options.add_experimental_option("detach", True)

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)

        driver.get("https://access.sfsu.edu/mydprc")

        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Current Students"))
        ).click()

        time.sleep(2)

        if password:
            try:
                password_field = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
                password_field.send_keys(password)
                driver.find_element(By.ID, "idSIButton9").click()
            except Exception as e:
                print(f"⚠️ Auto login failed: {e}")

        status_label.config(text="✅ Chrome (Selenium) launched", fg="green")
        poll_chrome_status(status_label, root)
        return driver

    except Exception as e:
        status_label.config(text="❌ Chrome launch failed", fg="red")
        messagebox.showerror("Chrome Error", f"Failed to launch Chrome: {e}")

def poll_chrome_status(status_label, root):
    global driver
    try:
        if driver:
            _ = driver.title
        else:
            status_label.config(text="🟡 Chrome not running", fg="orange")
            return
    except:
        status_label.config(text="🟡 Chrome not running", fg="orange")
        return

    root.after(2000, lambda: poll_chrome_status(status_label, root))
